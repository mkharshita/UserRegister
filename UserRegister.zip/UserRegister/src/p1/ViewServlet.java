package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Account;
import service.Validation;
import service.type;

/**
 * Servlet implementation class ViewServlet
 */
public class ViewServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String userName= req.getParameter("username");
		String password=req.getParameter("password");
		String rePassword=req.getParameter("repeatPassword");
		
		int age=Integer.parseInt(req.getParameter("age"));
		String[] technologies=req.getParameterValues("technology");
		String city= req.getParameter("city");
		String gender = req.getParameter("gender");
		String val = (req.getParameter("workexp"));
		Account acc=new Account(userName, password,rePassword, age, technologies, city, gender, val);
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		//out.println("Hiii"+userName);
		boolean check=new Validation().doCheck(acc);
		String post=new type().getProject(technologies);
		if(check==false) {
			out.print("Wrong Input");
		}
		
		else {
			out.println("<table>");
			out.println("<tr>");
			out.println("<td>");
			out.println("Name:");
			out.println("</td>");
			out.println("<td>");
			out.println(userName);
			out.println("</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td>");
			out.println("Age:");
			out.println("</td>");
			out.println("<td>");
			out.println(age);
			out.println("</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td>");
			out.println("Technologies Known:");
			out.println("</td>");
			out.println("<td>");
			String tech[]=technologies;
			for(String st:tech) {
				out.print(st+" ");
			}
			out.println("</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td>");
			out.println("City:");
			out.println("</td>");
			out.println("<td>");
			out.println(city);
			out.println("</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td>");
			out.println("Gender:");
			out.println("</td>");
			out.println("<td>");
			out.println(gender);
			out.println("</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td>");
			out.println("Work Experience:");
			out.println("</td>");
			out.println("<td>");
			out.println(val);
			out.println("</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td>");
			out.println("Post:");
			out.println("</td>");
			out.println("<td>");
			out.println(post);
			out.println("</td>");
			out.println("</tr>");
			out.println("</table>");
		}
		
	}

}
