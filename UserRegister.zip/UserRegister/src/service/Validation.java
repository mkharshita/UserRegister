package service;

import model.Account;

public class Validation 
{
	public boolean doCheck(Account a) 
	{
		if(a.getUsername().length()<3 || !(a.getUsername().matches("[A-Z][a-zA-Z]*"))) {
			return false;
		}
		if(!a.getPassword().equals(a.getRepassword())) {
			return false;
		}
		if(a.getAge()<18 || a.getAge()>60) {
			return false;
		}
		
		return true;
	}
}
