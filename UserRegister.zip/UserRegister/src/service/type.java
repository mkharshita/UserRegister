package service;

import java.util.Arrays;
import java.util.List;

public class type
{
	public String getProject(String[] tech)
	{
		List<String> list = Arrays.asList(tech);
		if(list.contains("java") && list.contains("angular"))
			return "Java Full Stack Engineer ";
		else if(list.contains("python") && list.contains("R"))
			return "AI ";
		else if(list.contains("oracle"))
			return "Datbase";
		else if(list.contains("juniper"))
			return "Network Admin";
		return "No Project Assigned";
	}
}
