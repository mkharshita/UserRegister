package model;

import java.util.Arrays;

public class Account 
{
	private String username;
	private String password;
	private String repassword;
	private int age;
	private String[] technologiesknown;
	private String city;
	private String gender;
	private String workexperience;
	public Account(String username, String password, String repassword, int age, String[] technologiesknown, String city, String gender,
			String workexperience) {
		super();
		this.username = username;
		this.password = password;
		this.repassword = repassword;
		this.age = age;
		this.technologiesknown = technologiesknown;
		this.city = city;
		this.gender = gender;
		this.workexperience = workexperience;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getRepassword() {
		return repassword;
	}
	public void setRepassword(String repassword) {
		this.repassword = repassword;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String[] getTechnologiesknown() {
		return technologiesknown;
	}
	public void setTechnologiesknown(String[] technologiesknown) {
		this.technologiesknown = technologiesknown;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getWorkexperience() {
		return workexperience;
	}
	public void setWorkexperience(String workexperience) {
		this.workexperience = workexperience;
	}
	@Override
	public String toString() {
		return "Account [username=" + username + ", password=" + password + ", age=" + age + ", technologiesknown="
				+ Arrays.toString(technologiesknown) + ", city=" + city + ", gender=" + gender + ", workexperience="
				+ workexperience + "]";
	}
	
}
